siegrin turu
